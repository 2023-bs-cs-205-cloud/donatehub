import React from 'react';
import { HeartIcon, UsersIcon, GlobeAltIcon, ShieldCheckIcon } from '@heroicons/react/24/outline';

const About: React.FC = () => {
  const features = [
    {
      icon: HeartIcon,
      title: 'Transparent Donations',
      description: 'Every donation is tracked and visible, ensuring complete transparency in how funds are used.',
    },
    {
      icon: UsersIcon,
      title: 'Community Driven',
      description: 'Built by the community, for the community. We connect donors with causes that matter.',
    },
    {
      icon: GlobeAltIcon,
      title: 'Global Impact',
      description: 'Support causes worldwide and make a real difference in communities around the globe.',
    },
    {
      icon: ShieldCheckIcon,
      title: 'Secure & Trusted',
      description: 'Your donations are secure with our advanced encryption and fraud protection systems.',
    },
  ];

  const stats = [
    { label: 'Campaigns Funded', value: '1,200+' },
    { label: 'Total Donations', value: '$2.5M+' },
    { label: 'Active NGOs', value: '500+' },
    { label: 'Happy Donors', value: '10,000+' },
  ];

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="relative bg-gradient-to-r from-primary-600 to-primary-700">
        <div className="absolute inset-0 bg-black opacity-20"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-white sm:text-5xl md:text-6xl">
              About DonateHub
            </h1>
            <p className="mt-6 text-xl text-primary-100 max-w-3xl mx-auto">
              Connecting compassionate donors with meaningful causes to create positive change in the world.
            </p>
          </div>
        </div>
      </div>

      {/* Mission Section */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
              Our Mission
            </h2>
            <p className="mt-6 text-lg text-gray-600 max-w-3xl mx-auto">
              DonateHub is dedicated to making charitable giving more accessible, transparent, and impactful. 
              We believe that everyone should have the opportunity to support causes they care about, and every 
              organization should have the tools to effectively manage and grow their fundraising efforts.
            </p>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
              Why Choose DonateHub?
            </h2>
            <p className="mt-6 text-lg text-gray-600 max-w-2xl mx-auto">
              We provide the tools and platform needed to make charitable giving simple, secure, and effective.
            </p>
          </div>
          
          <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {features.map((feature, index) => (
              <div key={index} className="text-center">
                <div className="flex items-center justify-center h-12 w-12 rounded-md bg-primary-500 text-white mx-auto">
                  <feature.icon className="h-6 w-6" />
                </div>
                <h3 className="mt-6 text-lg font-medium text-gray-900">
                  {feature.title}
                </h3>
                <p className="mt-2 text-base text-gray-500">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="bg-primary-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl font-bold text-white">
                  {stat.value}
                </div>
                <div className="mt-2 text-base text-primary-100">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Story Section */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-2 lg:gap-8 lg:items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
                Our Story
              </h2>
              <p className="mt-6 text-lg text-gray-600">
                DonateHub was born from a simple idea: making charitable giving more accessible and transparent. 
                Our founders, having experienced the challenges of both donating and fundraising, set out to create 
                a platform that would bridge the gap between donors and organizations.
              </p>
              <p className="mt-4 text-lg text-gray-600">
                Today, we're proud to support thousands of campaigns and help organizations raise millions of dollars 
                for causes that matter. From disaster relief to education, healthcare to environmental protection, 
                we're committed to making the world a better place, one donation at a time.
              </p>
            </div>
            <div className="mt-8 lg:mt-0">
              <div className="bg-white rounded-lg shadow-lg p-8">
                <blockquote className="text-lg text-gray-600">
                  "DonateHub has transformed how we approach fundraising. The transparency and ease of use 
                  have helped us connect with donors in ways we never thought possible."
                </blockquote>
                <div className="mt-4">
                  <div className="text-base font-medium text-gray-900">
                    Sarah Johnson
                  </div>
                  <div className="text-base text-gray-500">
                    Executive Director, Hope Foundation
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-primary-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-white sm:text-4xl">
              Ready to Make a Difference?
            </h2>
            <p className="mt-6 text-lg text-primary-100 max-w-2xl mx-auto">
              Join thousands of donors and organizations who are already making an impact through DonateHub.
            </p>
            <div className="mt-8 flex justify-center space-x-4">
              <a
                href="/register"
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-primary-600 bg-white hover:bg-gray-50 transition-colors"
              >
                Get Started
              </a>
              <a
                href="/campaigns"
                className="inline-flex items-center px-6 py-3 border border-white text-base font-medium rounded-md text-white hover:bg-primary-700 transition-colors"
              >
                Browse Campaigns
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
