import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { campaignAPI, donationAPI } from '../services/api';
import toast from 'react-hot-toast';
import {
  HeartIcon,
  CurrencyDollarIcon,
  CalendarIcon,
  UserIcon,
  ShareIcon,
  ArrowLeftIcon,
  CheckCircleIcon,
} from '@heroicons/react/24/outline';

interface Campaign {
  _id: string;
  title: string;
  description: string;
  category: string;
  goalAmount: number;
  raisedAmount: number;
  progressPercentage: number;
  createdBy: {
    _id: string;
    name: string;
    email: string;
  };
  createdAt: string;
  status: string;
}

interface Donation {
  _id: string;
  amount: number;
  donatedAt: string;
  donorId: {
    name: string;
  };
}

const CampaignDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();
  
  const [campaign, setCampaign] = useState<Campaign | null>(null);
  const [recentDonations, setRecentDonations] = useState<Donation[]>([]);
  const [loading, setLoading] = useState(true);
  const [donating, setDonating] = useState(false);
  const [donationAmount, setDonationAmount] = useState('');
  const [showDonationForm, setShowDonationForm] = useState(false);

  const fetchCampaignDetails = useCallback(async () => {
    try {
      setLoading(true);
      const response = await campaignAPI.getCampaign(id!);
      setCampaign(response.data.campaign);
      setRecentDonations(response.data.recentDonations || []);
    } catch (error) {
      console.error('Error fetching campaign:', error);
      toast.error('Failed to load campaign details');
      navigate('/campaigns');
    } finally {
      setLoading(false);
    }
  }, [id, navigate]);

  useEffect(() => {
    if (id) {
      fetchCampaignDetails();
    }
  }, [id, fetchCampaignDetails]);

  const handleDonation = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isAuthenticated) {
      toast.error('Please login to make a donation');
      navigate('/login');
      return;
    }

    if (user?.role !== 'donor') {
      toast.error('Only donors can make donations');
      return;
    }

    const amount = parseFloat(donationAmount);
    if (!amount || amount <= 0) {
      toast.error('Please enter a valid donation amount');
      return;
    }

    try {
      setDonating(true);
      await donationAPI.makeDonation({
        campaignId: id!,
        amount,
        paymentMethod: 'card'
      });
      
      toast.success('Donation successful! Thank you for your contribution.');
      setDonationAmount('');
      setShowDonationForm(false);
      fetchCampaignDetails(); // Refresh campaign data
    } catch (error: any) {
      const message = error.response?.data?.message || 'Donation failed';
      toast.error(message);
    } finally {
      setDonating(false);
    }
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      health: 'bg-red-100 text-red-800',
      education: 'bg-blue-100 text-blue-800',
      disaster: 'bg-yellow-100 text-yellow-800',
      others: 'bg-green-100 text-green-800',
    };
    return colors[category as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (!campaign) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Campaign Not Found</h1>
          <Link
            to="/campaigns"
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700"
          >
            <ArrowLeftIcon className="mr-2 h-4 w-4" />
            Back to Campaigns
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <div className="mb-6">
          <Link
            to="/campaigns"
            className="inline-flex items-center text-sm text-gray-500 hover:text-gray-700"
          >
            <ArrowLeftIcon className="mr-2 h-4 w-4" />
            Back to Campaigns
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
              {/* Campaign Header */}
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${getCategoryColor(campaign.category)}`}>
                        {campaign.category}
                      </span>
                      <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${
                        campaign.status === 'active' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {campaign.status}
                      </span>
                    </div>
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">
                      {campaign.title}
                    </h1>
                    <div className="flex items-center text-sm text-gray-500">
                      <UserIcon className="mr-2 h-4 w-4" />
                      <span>by {campaign.createdBy.name}</span>
                      <CalendarIcon className="ml-4 mr-2 h-4 w-4" />
                      <span>{formatDate(campaign.createdAt)}</span>
                    </div>
                  </div>
                  <button className="p-2 text-gray-400 hover:text-gray-600">
                    <ShareIcon className="h-5 w-5" />
                  </button>
                </div>

                {/* Progress Bar */}
                <div className="mb-4">
                  <div className="flex justify-between text-sm text-gray-600 mb-2">
                    <span>Progress</span>
                    <span>{campaign.progressPercentage}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div
                      className="bg-primary-600 h-3 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(campaign.progressPercentage, 100)}%` }}
                    ></div>
                  </div>
                </div>

                {/* Amounts */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-gray-500">Raised</div>
                    <div className="text-2xl font-bold text-gray-900">
                      {formatCurrency(campaign.raisedAmount)}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-gray-500">Goal</div>
                    <div className="text-2xl font-bold text-gray-900">
                      {formatCurrency(campaign.goalAmount)}
                    </div>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">About This Campaign</h2>
                <div className="prose max-w-none text-gray-700 whitespace-pre-wrap">
                  {campaign.description}
                </div>
              </div>
            </div>

            {/* Recent Donations */}
            {recentDonations.length > 0 && (
              <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-200">
                <div className="p-6 border-b border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-900">Recent Donations</h3>
                </div>
                <div className="divide-y divide-gray-200">
                  {recentDonations.map((donation) => (
                    <div key={donation._id} className="p-6 flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="flex-shrink-0">
                          <div className="h-10 w-10 bg-primary-100 rounded-full flex items-center justify-center">
                            <HeartIcon className="h-5 w-5 text-primary-600" />
                          </div>
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">
                            {donation.donorId.name}
                          </div>
                          <div className="text-sm text-gray-500">
                            {formatDate(donation.donatedAt)}
                          </div>
                        </div>
                      </div>
                      <div className="text-lg font-semibold text-gray-900">
                        {formatCurrency(donation.amount)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Donation Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 sticky top-8">
              {campaign.status === 'active' ? (
                <>
                  {!showDonationForm ? (
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">
                        Support This Campaign
                      </h3>
                      <p className="text-gray-600 mb-6">
                        Help make a difference by contributing to this cause.
                      </p>
                      {isAuthenticated && user?.role === 'donor' ? (
                        <button
                          onClick={() => setShowDonationForm(true)}
                          className="w-full inline-flex items-center justify-center px-4 py-3 border border-transparent text-base font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
                        >
                          <CurrencyDollarIcon className="mr-2 h-5 w-5" />
                          Make a Donation
                        </button>
                      ) : (
                        <div className="space-y-3">
                          <Link
                            to="/login"
                            className="w-full inline-flex items-center justify-center px-4 py-3 border border-transparent text-base font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700"
                          >
                            Login to Donate
                          </Link>
                          <Link
                            to="/register?role=donor"
                            className="w-full inline-flex items-center justify-center px-4 py-3 border border-gray-300 text-base font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                          >
                            Create Donor Account
                          </Link>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900 mb-4">
                        Make a Donation
                      </h3>
                      <form onSubmit={handleDonation} className="space-y-4">
                        <div>
                          <label htmlFor="amount" className="block text-sm font-medium text-gray-700 mb-2">
                            Donation Amount
                          </label>
                          <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                              <CurrencyDollarIcon className="h-5 w-5 text-gray-400" />
                            </div>
                            <input
                              type="number"
                              id="amount"
                              min="1"
                              step="0.01"
                              value={donationAmount}
                              onChange={(e) => setDonationAmount(e.target.value)}
                              className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                              placeholder="0.00"
                              required
                            />
                          </div>
                        </div>

                        {/* Quick Amount Buttons */}
                        <div className="grid grid-cols-3 gap-2">
                          {[25, 50, 100].map((amount) => (
                            <button
                              key={amount}
                              type="button"
                              onClick={() => setDonationAmount(amount.toString())}
                              className="px-3 py-2 text-sm border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-primary-500"
                            >
                              ${amount}
                            </button>
                          ))}
                        </div>

                        <div className="flex space-x-3">
                          <button
                            type="submit"
                            disabled={donating}
                            className="flex-1 inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed"
                          >
                            {donating ? (
                              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                            ) : (
                              <>
                                <CheckCircleIcon className="mr-2 h-4 w-4" />
                                Donate Now
                              </>
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={() => setShowDonationForm(false)}
                            className="px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                          >
                            Cancel
                          </button>
                        </div>
                      </form>
                    </div>
                  )}
                </>
              ) : (
                <div className="text-center">
                  <div className="text-gray-400 mb-4">
                    <CheckCircleIcon className="mx-auto h-12 w-12" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    Campaign Closed
                  </h3>
                  <p className="text-gray-600">
                    This campaign is no longer accepting donations.
                  </p>
                </div>
              )}

              {/* Campaign Stats */}
              <div className="mt-6 pt-6 border-t border-gray-200">
                <h4 className="text-sm font-medium text-gray-900 mb-3">Campaign Statistics</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-500">Progress</span>
                    <span className="font-medium">{campaign.progressPercentage}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Days Active</span>
                    <span className="font-medium">
                      {Math.ceil((Date.now() - new Date(campaign.createdAt).getTime()) / (1000 * 60 * 60 * 24))}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Status</span>
                    <span className="font-medium capitalize">{campaign.status}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CampaignDetail;
