import React, { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
// import { useAuth } from '../../context/AuthContext';
import { donationAPI } from '../../services/api';
import {
  HeartIcon,
  CurrencyDollarIcon,
  CalendarIcon,
  ArrowRightIcon,
  EyeIcon,
} from '@heroicons/react/24/outline';

interface Donation {
  _id: string;
  amount: number;
  donatedAt: string;
  status: string;
  transactionId: string;
  campaignId: {
    _id: string;
    title: string;
    category: string;
    status: string;
  };
}

interface DonationStats {
  totalDonations: number;
  totalAmount: number;
  averageAmount: number;
}

const DonorDonations: React.FC = () => {
  const [donations, setDonations] = useState<Donation[]>([]);
  const [stats, setStats] = useState<DonationStats>({
    totalDonations: 0,
    totalAmount: 0,
    averageAmount: 0,
  });
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  const fetchDonations = useCallback(async () => {
    try {
      setLoading(true);
      const response = await donationAPI.getDonorDonations({
        page: currentPage,
        limit: 10
      });
      
      setDonations(response.data.donations);
      setStats(response.data.stats);
      setTotalPages(response.data.pagination.pages);
    } catch (error) {
      console.error('Error fetching donations:', error);
    } finally {
      setLoading(false);
    }
  }, [currentPage]);

  useEffect(() => {
    fetchDonations();
  }, [fetchDonations]);

  const getCategoryColor = (category: string) => {
    const colors = {
      health: 'bg-red-100 text-red-800',
      education: 'bg-blue-100 text-blue-800',
      disaster: 'bg-yellow-100 text-yellow-800',
      others: 'bg-green-100 text-green-800',
    };
    return colors[category as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };


  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (loading && donations.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">My Donations</h1>
          <p className="text-gray-600 mt-2">
            Track your donation history and see the impact you've made.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="h-8 w-8 bg-primary-100 rounded-lg flex items-center justify-center">
                  <HeartIcon className="h-5 w-5 text-primary-600" />
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Total Donations</p>
                <p className="text-2xl font-semibold text-gray-900">{stats.totalDonations}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="h-8 w-8 bg-green-100 rounded-lg flex items-center justify-center">
                  <CurrencyDollarIcon className="h-5 w-5 text-green-600" />
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Total Donated</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {formatCurrency(stats.totalAmount)}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="h-8 w-8 bg-blue-100 rounded-lg flex items-center justify-center">
                  <CalendarIcon className="h-5 w-5 text-blue-600" />
                </div>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-500">Average Donation</p>
                <p className="text-2xl font-semibold text-gray-900">
                  {formatCurrency(stats.averageAmount)}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Donations List */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="px-6 py-4 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900">Donation History</h2>
          </div>

          {donations.length === 0 ? (
            <div className="p-12 text-center">
              <div className="text-gray-400 mb-4">
                <HeartIcon className="mx-auto h-12 w-12" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No donations yet</h3>
              <p className="text-gray-500 mb-6">
                Start making a difference by supporting campaigns that matter to you.
              </p>
              <Link
                to="/campaigns"
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700"
              >
                <HeartIcon className="mr-2 h-4 w-4" />
                Browse Campaigns
              </Link>
            </div>
          ) : (
            <>
              <div className="divide-y divide-gray-200">
                {donations.map((donation) => (
                  <div key={donation._id} className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-lg font-medium text-gray-900">
                            {donation.campaignId.title}
                          </h3>
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getCategoryColor(donation.campaignId.category)}`}>
                            {donation.campaignId.category}
                          </span>
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            donation.status === 'completed' 
                              ? 'bg-green-100 text-green-800' 
                              : donation.status === 'pending'
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {donation.status}
                          </span>
                        </div>
                        <div className="flex items-center space-x-6 text-sm text-gray-500">
                          <div className="flex items-center">
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            <span>{formatDateTime(donation.donatedAt)}</span>
                          </div>
                          <span>Transaction: {donation.transactionId}</span>
                        </div>
                      </div>
                      <div className="ml-6 flex-shrink-0">
                        <div className="text-right mb-3">
                          <div className="text-2xl font-bold text-gray-900">
                            {formatCurrency(donation.amount)}
                          </div>
                        </div>
                        <Link
                          to={`/campaigns/${donation.campaignId._id}`}
                          className="inline-flex items-center text-sm text-primary-600 hover:text-primary-500"
                        >
                          <EyeIcon className="mr-1 h-4 w-4" />
                          View Campaign
                          <ArrowRightIcon className="ml-1 h-3 w-3" />
                        </Link>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="px-6 py-4 border-t border-gray-200">
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-gray-700">
                      Showing page {currentPage} of {totalPages}
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                        disabled={currentPage === 1}
                        className="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Previous
                      </button>
                      <button
                        onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                        disabled={currentPage === totalPages}
                        className="px-3 py-2 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        Next
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Impact Summary */}
        {donations.length > 0 && (
          <div className="mt-8 bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Your Impact Summary</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-2">Campaigns Supported</h3>
                <p className="text-2xl font-bold text-gray-900">{stats.totalDonations}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-2">Lives Impacted (Estimated)</h3>
                <p className="text-2xl font-bold text-gray-900">{Math.round(stats.totalAmount / 50)}+</p>
              </div>
            </div>
            <div className="mt-6 pt-6 border-t border-gray-200">
              <p className="text-sm text-gray-600">
                Thank you for your generosity! Every donation makes a real difference in people's lives.
                Continue supporting causes you care about to create even more positive impact.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DonorDonations;
